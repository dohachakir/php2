<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Paiement Réussi</title>
</head>
<body>
    <h1>Paiement Réussi</h1>
    <p>Merci pour votre achat !</p>
</body>
</html>
